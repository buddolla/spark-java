package com.application;

import static spark.Spark.before;
import static spark.Spark.get;
import static spark.Spark.port;

import com.index.IndexController;
import com.util.Filters;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		 // Configure Spark
        port(4567);
        //staticFiles.location("/public");
        //staticFiles.expireTime(600L);
        
        before("*",                  Filters.addTrailingSlashes);
        before("*",                  Filters.handleLocaleChange);
        
        get("/index/",          IndexController.serveIndexPage);

	}

}
