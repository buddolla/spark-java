package com.application;

import static spark.Spark.before;
import static spark.Spark.get;
import static spark.Spark.port;
import static spark.Spark.post;

import com.index.IndexController;
import com.login.ANLController;
import com.login.ApplyController;
import com.login.HomeController;
import com.login.LoginController;
import com.util.Filters;

public class Application {

	public static void main(String[] args) {

		// Configure Spark
		port(4567);
		// staticFiles.location("/public");
		// staticFiles.expireTime(600L);

		before("*", Filters.addTrailingSlashes);
	    before("*", Filters.checkauthentication);

		get("/index/", IndexController.serveIndexPage);
		post("/loginsubmit/", LoginController.serveLoginForm);
		get("/apply/", HomeController.serveApplyPage);
		get("/anl/", HomeController.serveANLPage);
		get("/home/", HomeController.home);
		post("/anlsubmit/", ANLController.serveANLForm);
		post("/applyPage1Submit/", ApplyController.serveApplyPage1);
		post("/applyPage2Submit/", ApplyController.serveApplyPage2);
		get("/logout/", LoginController.logout);
	}

}
