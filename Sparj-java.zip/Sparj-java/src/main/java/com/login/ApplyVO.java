package com.login;

public class ApplyVO {

	private String firstname;

	private String lastname;

	private String income;

	private String address1;

	private String address2;

	private String city;

	private String state;

	private String zip;

	private String cofirstname;

	private String colastname;

	private String coincome;

	private String coaddress1;

	private String coaddress2;

	private String cocity;

	private String costate;

	private String cozip;

	public String getCofirstname() {
		return cofirstname;
	}

	public void setCofirstname(String cofirstname) {
		this.cofirstname = cofirstname;
	}

	public String getColastname() {
		return colastname;
	}

	public void setColastname(String colastname) {
		this.colastname = colastname;
	}

	public String getCoincome() {
		return coincome;
	}

	public void setCoincome(String coincome) {
		this.coincome = coincome;
	}

	public String getCoaddress1() {
		return coaddress1;
	}

	public void setCoaddress1(String coaddress1) {
		this.coaddress1 = coaddress1;
	}

	public String getCoaddress2() {
		return coaddress2;
	}

	public void setCoaddress2(String coaddress2) {
		this.coaddress2 = coaddress2;
	}

	public String getCocity() {
		return cocity;
	}

	public void setCocity(String cocity) {
		this.cocity = cocity;
	}

	public String getCostate() {
		return costate;
	}

	public void setCostate(String costate) {
		this.costate = costate;
	}

	public String getCozip() {
		return cozip;
	}

	public void setCozip(String cozip) {
		this.cozip = cozip;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getIncome() {
		return income;
	}

	public void setIncome(String income) {
		this.income = income;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "ApplyVO [firstname=" + firstname + ", lastname=" + lastname + ", income=" + income + ", address1="
				+ address1 + ", address2=" + address2 + ", city=" + city + ", state=" + state + ", zip=" + zip
				+ ", cofirstname=" + cofirstname + ", colastname=" + colastname + ", coincome=" + coincome
				+ ", coaddress1=" + coaddress1 + ", coaddress2=" + coaddress2 + ", cocity=" + cocity + ", costate="
				+ costate + ", cozip=" + cozip + "]";
	}

}
