package com.login;

import java.util.HashMap;
import java.util.Map;

import com.util.ViewUtil;

import spark.Request;
import spark.Response;
import spark.Route;

public class HomeController {
	
	public static Route serveApplyPage = (Request request, Response response) -> {
		Map<String, Object> model = new HashMap<>();
		return ViewUtil.render(request, model, "applyPage1");
	};
	
	public static Route serveANLPage = (Request request, Response response) -> {
		Map<String, Object> model = new HashMap<>();
		return ViewUtil.render(request, model, "anlSearch");
	};
	
	public static Route home = (Request request, Response response) -> {
		Map<String, Object> model = new HashMap<>();
		System.out.println(request.session(false).id() + "" + request.session(false).isNew());
		model.put("sessid", request.session(false).id());
		return ViewUtil.render(request, model, "home");
	};

}
