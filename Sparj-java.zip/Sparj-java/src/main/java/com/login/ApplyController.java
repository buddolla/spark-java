package com.login;

import static com.util.RequestUtil.maptObject;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.util.ViewUtil;

import spark.Request;
import spark.Response;
import spark.Route;

public class ApplyController {

	public static Route serveApplyPage1 = (Request request, Response response) -> {
		Map<String, Object> model = new HashMap<>();
		Map<String, String> map = maptObject(request, Map.class);
		System.out.println(map);
		request.session(false).attribute("page1", map);
		return ViewUtil.render(request, model, "applyPage2");
	};
	
	public static Route serveApplyPage2 = (Request request, Response response) -> {
		Map<String, Object> model = new HashMap<>();
		Map<String, String> map =request.session(false).attribute("page1");
		Map<String, String> map1 = maptObject(request, Map.class);
		map.putAll(map1);
		ApplyVO vo=new ObjectMapper().convertValue(map, ApplyVO.class);
		System.out.println(vo);
		model.put("applyVO", vo);
		//request.session().attribute("applyVO", applyVO);
		//model.put("applyVO", vo);
		return ViewUtil.render(request, model, "applyResults");
	};
	
}
