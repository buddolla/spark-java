package com.login;

import java.util.HashMap;
import java.util.Map;

import com.util.ViewUtil;

import spark.Request;
import spark.Response;
import spark.Route;

public class ANLController {
	
	public static Route serveANLForm = (Request request, Response response) -> {
		Map<String, Object> model = new HashMap<>();
		model.put("accountnumber", request.queryParams("accountnumber"));
		return ViewUtil.render(request, model, "anlResults");
	};

}
