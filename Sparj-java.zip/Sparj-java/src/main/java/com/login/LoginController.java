package com.login;

import static com.util.RequestUtil.maptObject;
import static com.util.UserUtils.authenticate;

import java.util.HashMap;
import java.util.Map;

import com.util.ViewUtil;

import spark.Request;
import spark.Response;
import spark.Route;

public class LoginController {

	public static Route serveLoginForm = (Request request, Response response) -> {
		Map<String, Object> model = new HashMap<>();
		/*
		 * QueryParamsMap mq=request.queryMap(); Map<String, String>
		 * map1=request.queryMap().toMap().entrySet().stream().collect(Collectors.toMap(
		 * Entry::getKey, v->v.getValue()[0]));
		 */
		LoginVO vo = maptObject(request, LoginVO.class);
		if (authenticate(vo)) {
			model.put("sessid", request.session(true).id());
	
			return ViewUtil.render(request, model, "home");
		}
		model.put("invaliduser", "Y");
		return ViewUtil.render(request, model, "login");
	};
	
	public static Route logout = (Request request, Response response) -> {
		Map<String, Object> model = new HashMap<>();
		request.session().invalidate();
		return ViewUtil.render(request, model, "login");
	};

}