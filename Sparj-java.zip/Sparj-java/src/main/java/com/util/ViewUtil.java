package com.util;

import java.util.Map;

import spark.ModelAndView;
import spark.Request;
import spark.template.thymeleaf.ThymeleafTemplateEngine;

public class ViewUtil {
	public static String render(Request request, Map<String, Object> model, String templatePath) {
		return new ThymeleafTemplateEngine().render(new ModelAndView(model, templatePath));
	}

}
