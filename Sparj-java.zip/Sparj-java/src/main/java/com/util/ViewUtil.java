package com.util;


 
import java.util.Map;


import spark.ModelAndView;
import spark.Request;
import spark.template.thymeleaf.ThymeleafTemplateEngine;


import static com.util.RequestUtil.*;
 

public class ViewUtil {
	 public static String render(Request request, Map<String, Object> model, String templatePath) {
		// model.put("msg", new MessageBundle(getSessionLocale(request)));
	        /*model.put("currentUser", getSessionCurrentUser(request));
	        model.put("WebPath", Path.Web.class); // Access application URLs from templates
*/	        return new ThymeleafTemplateEngine().render(new ModelAndView(model, templatePath));
	    }

}

