package com.util;

import com.login.LoginVO;

public class UserUtils {

	public static boolean authenticate(LoginVO vo) {
		UserDB userDB = UserDB.getInstance();
		if (userDB.userExist(vo.getUsername())
				&& userDB.get(vo.getUsername()).getUserpassword().equalsIgnoreCase(vo.getPassword()))
			return true;
		else
			return false;
	}

}
