package com.util;

import java.util.HashMap;
import java.util.Map;

public class UserDB {

	private Map<String, User> map = null;
	private static UserDB userDB = null;

	private UserDB() {
		map = new HashMap<>();
		// UserDB userDB = UserDB.getInstance();
	}

	public static UserDB getInstance() {
		if (userDB == null) {
			userDB = new UserDB();
			userDB.put("user1", new User("111", "user1", "user1"));
			userDB.put("user2", new User("222", "user2", "user2"));

		}
		return userDB;
	}

	public User get(String username) {
		return map.get(username);
	}

	public void put(String username, User user) {
		map.put(username, user);
	}

	public boolean userExist(String username) {
		return map.containsKey(username);
	}

}
