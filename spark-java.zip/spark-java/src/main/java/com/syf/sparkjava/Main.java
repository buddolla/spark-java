package com.syf.sparkjava;
import static spark.Spark.after;
import static spark.Spark.before;
import static spark.Spark.exception;
import static spark.Spark.get;

import spark.Route;

public class Main {
	public static void main(String[] args) {

		// get route
		get("/hello", (req, res) -> "Hello Form Spark application");

		// get parameter route
		get("/hello/:name", (req, res) -> "Hello " + req.params(":name"));

		// Before-filters are evaluated before each request
		before((request, response) -> {
			System.out.println("before request");
		});

		// After-filters are evaluated after each request, and can read the
		// request and read/modify the response:
		after((request, response) -> {
			response.header("header", "set by after filter");
		});

		get("/getsession", (request, response) -> {
			String s = "Hello Form Spark application";
			response.cookie("mycookie", "Hello Form Spark application");  
			request.session(true);
			return s+"::" +request.session().id();
		});

		// Exception
		get("/throwexception", (request, response) -> {
			throw new NotFoundException();
		});

		exception(NotFoundException.class, (e, request, response) -> {
			response.status(404);
			response.body("Resource not found");
		});

	}

	

}