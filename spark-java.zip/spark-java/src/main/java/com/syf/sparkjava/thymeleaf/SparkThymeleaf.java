package com.syf.sparkjava.thymeleaf;

import static spark.Spark.get;

import java.util.HashMap;
import java.util.Map;

import spark.ModelAndView;
import spark.Request;
import spark.Response;
import spark.template.thymeleaf.ThymeleafTemplateEngine;

public class SparkThymeleaf {

	public static void main(String[] args) {
		// port(4567);

		get("/leaf/:name", SparkThymeleaf::message, new ThymeleafTemplateEngine());
	}

	public static ModelAndView message(Request req, Response res) {

		Map<String, Object> params = new HashMap<>();
		params.put("name", req.params(":name"));
		return new ModelAndView(params, "hello");
	}
}