package com.syf.sparkjava;

public class NotFoundException extends Exception {

}
